import React from "react";
import clsx from "classnames";
import BackDrop from "./BackDrop";
import { ReactComponent as MetaMask } from "../../assets/metamask.svg";
import { ReactComponent as Wallet } from "../../assets/wallet.svg";

const ProviderModal = ({ onSelect, onClose, visible }) => {
  return (
    <>
      <BackDrop onClick={onClose} visible={visible} />
      <div
        className={clsx(
          "z-[10] flex items-center justify-center flex-col md:space-y-[59px] space-y-[30px] fixed top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%] bg-pink shadowed h-[50vh] w-[50vh] md:h-[597px] md:w-[597px] rounded-[50%] opacity-0 pointer-events-none",
          {
            "pointer-events-auto opacity-[1] animate__animated animate__fadeIn":
              visible,
          }
        )}
      >
        <h3 className="text-[25px] md:text-[40px] text-[#1A1515] text-center font-bold">
          Select provider
        </h3>
        <div className="flex items-center justify-center space-x-[31px]">
          <MetaMask
            className="cursor-pointer"
            onClick={() => onSelect("metamask")}
          />
          <Wallet
            className="cursor-pointer"
            onClick={() => onSelect("wallet")}
          />
        </div>
      </div>
    </>
  );
};

export default ProviderModal;
