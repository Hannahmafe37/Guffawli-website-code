import HeroImage from "../../assets/hero.png";
import Icon1 from "../../assets/hero-icon-1.svg";
import Icon2 from "../../assets/hero-icon-2.svg";
import Icon3 from "../../assets/hero-icon-3.svg";
import Icon4 from "../../assets/hero-icon-4.svg";
import WalletIcon from "../../assets/wallet-icon.svg";
import FairIcon from "../..//assets/fair-icon.svg";
import WhaleIcon from "../../assets/whale-icon.svg";
import ContractIcon from "../../assets/contract-icon.svg";
import AuditIcon from "../../assets/audit-icon.svg";
import CommunityIcon from "../../assets/community-icon.svg";
import BeInImage from "../../assets/beIn-logo.svg";
import CoinMarketBagImage from "../../assets/coinbag.svg";
import CoinTelegraphImage from "../../assets/coin-telegraph.svg";
import NewsbtsImage from ".././../assets/newsbtc.svg";
import CoinCodeImage from "../../assets/coin-codex.svg";
import AnalyticsImage from "../../assets/analytics.svg";
import CoinMarketBagMobileImage from "../../assets/coinmarketbagmobile.svg";
import CoinTelegraphMobileImage from "../../assets/cointelegraphmobile.svg";
import NewsbtsMobileImage from ".././../assets/newsbtcmobile.svg";
import CoinCodeMobileImage from "../../assets/coindexmobile.svg";
import AnalyticsMobileImage from "../../assets/analyticsinsightmobile.svg";
import BeInMobileImage from "../../assets/beInmobile.svg";
// import Timer from "../../components/timer/Timer";
import "animate.css";
import roadmapMarker from "../../assets/roadmap-marker.svg";
import PopBonus from "../../assets/pop-bonus.svg";

import Accordion from "../../components/faq/Accordion";
import "./index.css";
import { Link } from "react-router-dom";
import { HashLink } from "react-router-hash-link";

const Mechanism = () => {
  return (
    <div className="blurred-coin-left">
      <div className="mechanism-wrapper">
        <div className="max-width flex-container animate__animated animate__fadeInLeft animate__slow">
          <div className="col-half">
            <h4 className="hero-title-text">
              {" "}
              Guffawli Token
              <br /> Unruggable
              <br />
              Mechanism
            </h4>
            <div className="body-container w-70">
              <p className="body-text">
                We take the safety of holders' funds really seriously, and
                therefore we have taken the following measures to safeguard our
                community:
              </p>
            </div>
          </div>
          <div className="col-half">
            <div className="mechanism-row">
              <div className="mechanism-icon-box">
                <div className="text-center">
                  <img
                    alt="guffawli-web"
                    src={WalletIcon}
                    className="mechaqnism-icon"
                  />
                  <p className="mechanism-icon-label">
                    6% Team Wallet Allocation
                  </p>
                </div>
              </div>
              <div className="mechanism-icon-box">
                <div className="text-center">
                  <img
                    alt="guffawli-web"
                    src={FairIcon}
                    className="mechaqnism-icon"
                  />
                  <p className="mechanism-icon-label">
                    Fairly Distributed Presale
                  </p>
                </div>
              </div>
              <div className="mechanism-icon-box">
                <div className="text-center">
                  <img
                    alt="guffawli-web"
                    src={WhaleIcon}
                    className="mechaqnism-icon"
                  />
                  <p className="mechanism-icon-label">
                    No Presale Wallets would hold &gt; 1%
                  </p>
                </div>
              </div>
            </div>
            <div className="mechanism-row">
              <div className="mechanism-icon-box">
                <div className="text-center">
                  <img
                    alt="guffawli-web"
                    src={ContractIcon}
                    className="mechaqnism-icon"
                  />
                  <p className="mechanism-icon-label">
                    No minting function exists in the contract
                  </p>
                </div>
              </div>
              <div className="mechanism-icon-box">
                <div className="text-center">
                  <img
                    alt="guffawli-web"
                    src={AuditIcon}
                    className="mechaqnism-icon"
                  />
                  <p className="mechanism-icon-label">
                    Contract Audit In Progress
                  </p>
                </div>
              </div>
              <div className="mechanism-icon-box">
                <div className="text-center">
                  <img
                    alt="guffawli-web"
                    src={CommunityIcon}
                    className="mechaqnism-icon"
                  />
                  <p className="mechanism-icon-label">Community driven token</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Roadmap = () => {
  return (
    <div className="roadmap-wrapper" id="roadmap">
      <div>
        <h4 className="hero-title-text text-center">Roadmap</h4>
      </div>
      <div className="road-container">{/* <hr className='road-track'/> */}</div>
      <div className="phase-row">
        <div>
          <div className="marker-container">
            <img alt="guffawli-web" src={roadmapMarker} />
          </div>
          <div className="phase-card">
            <div>
              <h4 className="phase-title">Phase 1</h4>
              <ul>
                <li>
                  <p className="phase-item">Website launch</p>
                </li>
                <li>
                  <p className="phase-item">Social media growth</p>
                </li>
                <li>
                  <p className="phase-item">
                    Operation ‘Tell the <br />
                    world about Guffawl
                  </p>
                </li>
              </ul>
            </div>
            <div></div>
          </div>
        </div>

        <div>
          <div className="marker-container">
            <img alt="guffawli-web" src={roadmapMarker} />
          </div>
          <div className="phase-card">
            <div>
              <h4 className="phase-title">Phase 2</h4>
              <ul>
                <li>
                  <p className="phase-item">Presale</p>
                </li>
                <li>
                  <p className="phase-item">Partnership and Collaboration</p>
                </li>
              </ul>
            </div>
            <div></div>
          </div>
        </div>
        <div>
          <div className="marker-container">
            <img alt="guffawli-web" src={roadmapMarker} />
          </div>
          <div className="phase-card">
            <div>
              <h4 className="phase-title">Phase 3</h4>
              <ul>
                <li>
                  <p className="phase-item">Guffawli product launch</p>
                </li>
                <li>
                  <p className="phase-item">
                    AMA session with team and product review
                  </p>
                </li>
              </ul>
            </div>
            <div></div>
          </div>
        </div>
      </div>
    </div>
  );
};

const AsSeenOn = () => {
  return (
    <>
      <div className="as-seen-on-wrapper desktop-only">
        <div className="animate__animated animate__fadeInDown animate__slow">
          <div>
            <h4 className="hero-title-text text-center">As Seen on</h4>
          </div>
          <div className="as-seen-on-images-wrapper">
            <img alt="guffawli-web" src={BeInImage} />
            <img alt="guffawli-web" src={CoinMarketBagImage} />
            <img alt="guffawli-web" src={CoinTelegraphImage} />
          </div>
          <div className="as-seen-on-images-wrapper">
            <img alt="guffawli-web" src={NewsbtsImage} />
            <img alt="guffawli-web" src={CoinCodeImage} />
            <img alt="guffawli-web" src={AnalyticsImage} />
          </div>
        </div>
      </div>

      <div className="as-seen-on-wrapper mobile-only">
        <div>
          <h4 className="hero-title-text text-center">As Seen on</h4>
        </div>

        <div className="as-seen-on-images-wrapper">
          <img alt="guffawli-web" src={BeInMobileImage} />
          <img alt="guffawli-web" src={CoinMarketBagMobileImage} />
        </div>
        <div className="as-seen-on-images-wrapper">
          <img alt="guffawli-web" src={CoinTelegraphMobileImage} />
          <img alt="guffawli-web" src={NewsbtsMobileImage} />
        </div>
        <div className="as-seen-on-images-wrapper">
          <img alt="guffawli-web" src={CoinCodeMobileImage} />
          <img alt="guffawli-web" src={AnalyticsMobileImage} />
        </div>
      </div>
    </>
  );
};

const FAQ = () => {
  const FAQdata = [
    {
      title: "Is the liquidity locked?",
      content:
        "Yes. Guffawli’s liquidity is locked for two years on the Binance Smart Chain.",
      id: 1,
    },
    {
      title: " Is there a reward for holders?",
      content:
        "Guffawli will reward those who hold the project tokens by leaving them in their wallets.?",
      id: 2,
    },
    {
      title: "What is Automatic Liquidity?",
      content:
        "An Automated Liquidity Pool (LP) project has an operational function that rewards holders. First, the smart contract attracts tokens from those exchanging and then adds these amounts of the tokens to the liquidity. This is a very good method of strengthening token price and liquidity.",
      id: 3,
    },
    {
      title: "How do we cope with competition in the market?",
      content:
        "Guffawli Token has a huge audience in the BSC ecosystem, with a good token distribution model that profits everyone. Particularly, the Guffawli Token is backed by a clear and credible team. There are still a lot of upcoming events and innovations yet to be announced. With these, Guffawli would do very well against competitors.",
      id: 4,
    },
    {
      title: "Why was Guffawli built on the Binance Smart Chain?",
      content:
        "Guffawli is built on the Binance Smart Chain to foster speed and growth in an affordable way.",
      id: 5,
    },
  ];

  return (
    <div
      className="faq-wrapper animate__animated animate__fadeInRight animate__slow"
      id="faq"
    >
      <div className="max-width">
        <div>
          <h4 className="hero-title-text text-center desktop-only">
            Frequently Asked Questions
          </h4>

          <h4 className="hero-title-text text-center mobile-only">
            Frequently Asked
            <br />
            Questions
          </h4>
        </div>
        <div>
          {FAQdata.map((item, index) => (
            <Accordion
              title={item.title}
              content={item.content}
              key={item.title + index}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

const Home = () => {
  return (
    <div className="blurred-coin">
      <div className="home-header-wrapper">
        <div className="flex-container-home-header max-width">
          <div className="col-half">
            <div className="typewriter">
              <h4 className="hero-title-text">
                <span>Join the</span>{" "}
                <span className="purple-text">happiest</span>
                <br /> <span></span>community
                <br /> with Guffawli Token
              </h4>
            </div>
            <div className="home-body-container animate__animated animate__fadeInLeft animate__slow">
              <p className="home-body-text">
                Guffawli is ownerless, fully decentralized, and supported by its
                community of enthusiasts.
              </p>
            </div>
            <div className="button-container animate__animated animate__fadeInUp animate__slow">
              <Link to={"/buy"}>
                <button className="hero-button cursor-pointer">
                  Buy Presale
                </button>
              </Link>
            </div>
            <div className="hero-icons-row animate__animated animate__rubberBand animate__slow">
              <img alt="guffawli-web" src={Icon1} className="hero-icon" />
              <img alt="guffawli-web" src={Icon2} className="hero-icon" />
              <img alt="guffawli-web" src={Icon3} className="hero-icon" />
              <img alt="guffawli-web" src={Icon4} className="hero-icon" />
            </div>
          </div>

          <div className="col-half">
            <img
              alt="guffawli-web"
              src={HeroImage}
              className="hero-image animate__animated animate__bounceIn animate__slow"
            />
          </div>
        </div>
        <div>
          <HashLink to="/buy#how-to-buy">
            <div className="max-width pop-container cursor-pointer">
              <img alt="guffawli-web" src={PopBonus} className="pop-bonus" />
            </div>
          </HashLink>
          <div>
            <div className="flex-container gap-30">
              {/* <h4 className="text-center">Hurry before presale ends in</h4>
              <Timer /> */}
            </div>
          </div>
        </div>
      </div>
      <Mechanism />
      <Roadmap />
      <AsSeenOn />

      <FAQ />
    </div>
  );
};

export default Home;
