import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import Logo from "../../assets/logo.png";
import padlock from "../../assets/padlock.png";
import MobileLogo from "../../assets/mobile-logo.svg";
import "./index.css";
import Hamburger from "../../assets/hamburger.svg";
import CLoseBtn from "../../assets/close-notif.svg";
import { NavHashLink } from "react-router-hash-link";
import WhitePaper from "../../assets/documents/Guffawli.pdf";

const MenuItem = ({ text, url, icon, className }) => {
  return (
    <>
      <NavLink
        to={url}
        className={({ isActive }) =>
          isActive
            ? `active-web-navlink flex items-center space-x-1 ${className}`
            : `inactive-web-navlink flex items-center space-x-1 ${className}`
        }
      >
        {icon && icon}
        <span>{text}</span>
      </NavLink>
    </>
  );
};

const MobileMenuItem = ({ text, onClick, url, icon, className }) => {
  return (
    <>
      <NavLink
        to={url}
        className={({ isActive }) =>
          `flex items-center space-x-1 ${text?.toLowerCase()} ${className} ${
            isActive ? "active-mobile-navlink" : "inactive-mobile-navlink"
          }`
        }
        onClick={onClick}
      >
        {icon && icon}
        <span>{text}</span>
      </NavLink>
    </>
  );
};

export const MobileMenu = () => {
  const [isOpen, setIsOpen] = useState(false);

  const MobileMenuBody = () => {
    return (
      <div>
        <div className="mobile-menu-logo-wrapper ">
          <img alt="guffawli-web" src={MobileLogo} />
        </div>
        <div className="">
          <MobileMenuItem
            url="/"
            text="Home"
            onClick={() => setIsOpen(!isOpen)}
          />
          <MobileMenuItem
            url="/about"
            text="About"
            onClick={() => setIsOpen(!isOpen)}
          />
          <MobileMenuItem
            url="/tokenomics"
            text="Tokenomics"
            onClick={() => setIsOpen(!isOpen)}
          />
          <NavHashLink
            smooth
            activeClassName="active-mobile-navlink"
            className="inactive-mobile-navlink"
            to="/#roadmap"
            onClick={() => setIsOpen(!isOpen)}
          >
            Roadmap
          </NavHashLink>
          <a
            href={WhitePaper}
            target="_blank"
            rel="noreferrer"
            className="inactive-mobile-navlink"
          >
            WhitePaper
          </a>
          <NavHashLink
            smooth
            activeClassName="active-mobile-navlink"
            className="inactive-mobile-navlink"
            to="/#faq"
            onClick={() => setIsOpen(!isOpen)}
          >
            FAQ
          </NavHashLink>
          <MobileMenuItem url="/buy" text="Buy" />
          <MobileMenuItem
            className={"!flex hi"}
            url="/buy"
            text="Claim"
            icon={<img src={padlock} className="h-5 mr-1" alt="padlock" />}
          />
          {/* <a
            href="https://smile.guffawli.io/"
            className="inactive-mobile-navlink"
          >
            Login
          </a> */}
          <div className="close-button-wrapper">
            <img
              alt="guffawli-web"
              src={CLoseBtn}
              onClick={() => setIsOpen(false)}
            />
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className={` ${isOpen ? "mobile-menu-body" : "mobile-only"}`}>
      <div className="mobile-menu-wrapper">
        {!isOpen && (
          <div className="mobile-menu">
            <div className="">
              <img alt="guffawli-web" src={MobileLogo} />
            </div>
            <div>
              <img
                alt="guffawli-web"
                src={Hamburger}
                onClick={() => setIsOpen(true)}
              />
            </div>
          </div>
        )}
      </div>
      <div>
        {isOpen && (
          <div className=" mt-30">
            <MobileMenuBody />
          </div>
        )}
      </div>
    </div>
  );
};

const WebMenu = () => {
  return (
    <>
      <div className=" desktop-only max-width">
        <div className="menu-wrapper">
          <MenuItem url="/" text="Home" />
          <MenuItem url="/about" text="About" />
          <MenuItem url="/tokenomics" text="Tokenomics" />
          <MenuItem url="/buy" text="Buy" />
          <MenuItem
            url="/buy"
            text="Claim"
            icon={<img src={padlock} className="h-5 mr-1" alt="padlock" />}
            className="!flex"
          />
          <img alt="guffawli-web" src={Logo} className="logo-image" />
          <NavHashLink
            smooth
            activeClassName="active-web-navlink"
            className="inactive-web-navlink"
            to="/#roadmap"
          >
            Roadmap
          </NavHashLink>
          <a
            href={WhitePaper}
            className="inactive-web-navlink"
            target="_blank"
            rel="noreferrer"
          >
            WhitePaper
          </a>
          <NavHashLink
            smooth
            activeClassName="active-web-navlink"
            className="inactive-web-navlink"
            to="/#faq"
          >
            FAQ
          </NavHashLink>
          {/* <a href="https://smile.guffawli.io/" className="inactive-web-navlink">
            Login
          </a> */}
        </div>
      </div>
    </>
  );
};

export default WebMenu;
