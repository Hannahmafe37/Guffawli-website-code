import { ReactComponent as BNB } from "../assets/bnb.svg";

export const buyOptions = [
  {
    icon: <BNB className="h-[100px]" />,
    header: "Buy With BNB",
    text: "This option will allow you to purchase BNB that will be sent to your wallet by our partner, Transak. You will then be able to use this BNB to purchase GUFF. Click “Buy BNB With Card” to begin and follow the on screen steps. We recommend purchasing a minimum of $15 worth of BNB to cover the minimum GUFF purchase.",
  },
  // {
  //   icon: <Usdt />,
  //   header: "Buy With USDT",
  //   text: "Please ensure you have at least $15 of USDT in your wallet before commencing the transaction. Type in the amount of GUFF you wish to purchase (1,000 minimum). Click “Convert USDT”. You will then be asked to approve the purchase TWICE. The first approval is for the USDT contract and the second is for the transaction amount. Please ensure you go through both approval steps in order to complete the transaction.",
  // },
];

export const buyMethods = ["BNB"];
