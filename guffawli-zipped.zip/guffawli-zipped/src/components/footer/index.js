/* eslint-disable jsx-a11y/anchor-is-valid */
import "./index.css";
import EarlyAccess from "../earlyaccess";
import FooterLogo from "../../assets/footer-logo.svg";
import TelegramIcon from "../../assets/telegram.svg";
import TwitterIcon from "../../assets/twitter.svg";
import { Link } from "react-router-dom";
import { NavHashLink } from "react-router-hash-link";
import WhitePaper from "../../assets/documents/Guffawli.pdf";

const BottomSection = () => {
  return (
    <div>
      <div>
        <hr className="footer-bar" />
      </div>
      <div className="bottom-section-container">
        <div>
          <h4 className="footer-menu">
            Copyright © 2022 Guffawli Token. All rights reserved
          </h4>
        </div>
        <div className="flex-container gap-30">
          <div>
            <h4 className="connect-text">Connect With Us</h4>
          </div>
          <div className="icon-row">
            <a href="https://t.me/GuffawliTokenOfficial">
              <img alt="guffawli-web" src={TelegramIcon} />
            </a>
            <a href="https://twitter.com/Guffawli_Token">
              <img alt="guffawli-web" src={TwitterIcon} />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

const MainFooter = () => {
  return (
    <div className="footer-bg">
      <div className="footer-row">
        <div className="col-20">
          <img alt="guffawli-web" src={FooterLogo} />
        </div>
        {/* <div className='col-20'>
                <h6 className='footer-section-title'>LANGUAGE</h6>
                <div className='mt-20'>
                </div>
            </div> */}

        <div className="col-20">
          <div>
            <h6 className="footer-section-title">LINKS</h6>
          </div>
          <div className="links-container">
            <div>
              <Link to="/about">
                <h6 className="footer-menu">About</h6>
              </Link>
              <Link to="/tokenomics">
                <h6 className="footer-menu">Tokenomics</h6>
              </Link>
              <NavHashLink smooth to="/#roadmap">
                <h6 className="footer-menu">Roadmap</h6>
              </NavHashLink>
              <h6 className="footer-menu">Audit</h6>
            </div>
          </div>
        </div>
        <div className="col-40">
          <h6 className="footer-section-title">LINKS</h6>
          <div>
            <a href={WhitePaper}>
              <h6 className="footer-menu">Whitepaper</h6>
            </a>
            <Link to="/buy">
              <h6 className="footer-menu">Buy Presale</h6>
            </Link>
          </div>
        </div>
      </div>
      <BottomSection />
    </div>
  );
};

const MainFooterMobile = () => {
  return (
    <div className="footer-bg">
      <div>
        <img
          alt="guffawli-web"
          src={FooterLogo}
          className="mobile-footer-logo"
        />
      </div>
      <div className="mt-50">
        <h6 className="footer-section-title">LINKS</h6>
        <div className="links-container">
          <div>
            <Link to="/about">
              <h6 className="footer-menu">About</h6>
            </Link>
            <Link to="/tokenomics">
              <h6 className="footer-menu">Tokenomics</h6>
            </Link>
            <NavHashLink smooth to="/#roadmap">
              <h6 className="footer-menu">Roadmap</h6>
            </NavHashLink>
            <a className="footer-menu">Audit</a>
          </div>
          <div>
            <h6 className="footer-menu">Whitepaper</h6>
            <NavHashLink smooth to="/#faq">
              <h6 className="footer-menu">FAQ</h6>
            </NavHashLink>
            <Link to="/buy" className="footer-menu">
              Buy Presale
            </Link>
          </div>
        </div>
        <div className="mt-50">
          <div>
            <h4 className="connect-text">Connect With Us</h4>
          </div>
          <div className="icon-row">
            <a href="https://t.me/GuffawliTokenOfficial">
              <img alt="guffawli-web" src={TelegramIcon} />
            </a>
            <a href="https://twitter.com/Guffawli_Token">
              <img alt="guffawli-web" src={TwitterIcon} />
            </a>
          </div>
        </div>

        <div className="mt-50">
          <hr className="footer-bar" />
          <h4 className="footer-menu mt-20">
            Copyright © 2022 Guffawli Token. All rights reserved
          </h4>
        </div>
      </div>
    </div>
  );
};

const Footer = () => {
  // const { t } = useTranslation();
  // const [click, setClick] = useState(false)
  // const handleClick = () => setClick(!click)
  // const [dropdown, setDropdown] = useState(false);
  // let ref = useRef();
  // const currentLanguageCode = cookies.get('i18next') || 'en'
  // const currentLanguage = Languages.find((l) => l.code === currentLanguageCode)

  // useEffect(() => {

  //     document.body.dir = currentLanguage.dir || 'ltr'

  //     const handler = (event) => {
  //     if (dropdown && ref.current && !ref.current.contains(event.target)) {
  //         setDropdown(false);
  //     }
  //     };
  //     document.addEventListener("mousedown", handler);
  //     document.addEventListener("touchstart", handler);
  //     return () => {
  //     // Cleanup the event listener
  //     document.removeEventListener("mousedown", handler);
  //     document.removeEventListener("touchstart", handler);
  //     };
  // }, [dropdown, currentLanguage]);

  // const onMouseEnter = () => {
  //     window.innerWidth > 960 && setDropdown(true);
  // };

  // const onMouseLeave = () => {
  //     window.innerWidth > 960 && setDropdown(false);
  // };

  return (
    <div className="footer-wrapper">
      <div className="desktop-only">
        <EarlyAccess />
        <MainFooter />
      </div>
      <div className="mobile-only">
        <EarlyAccess />
        <MainFooterMobile />
      </div>
    </div>
  );
};

export default Footer;
