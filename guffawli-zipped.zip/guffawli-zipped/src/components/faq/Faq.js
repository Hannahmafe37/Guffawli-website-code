import Accordion from "./Accordion";
import './faq.css'


const faqData = [
    {
        title : "Is the liquidity locked?",
        content : "Yes. Guffawli’s liquidity is locked for two years on the Binance Smart Chain.",
        id: 1
    },
    {
        title : " Is there a reward for holders?",
        content: "Guffawli will reward those who hold the project tokens by leaving them in their wallets.?",
        id: 2
    },
    {
        title : "What is Automatic Liquidity?",
        content: "An Automated Liquidity Pool (LP) project has an operational function that rewards holders. First, the smart contract attracts tokens from those exchanging and then adds these amounts of the tokens to the liquidity. This is a very good method of strengthening token price and liquidity.",
        id: 3
    },
    {
        title : "How do we cope with competition in the market?",
        content: "Guffawli Token has a huge audience in the BSC ecosystem, with a good token distribution model that profits everyone. Particularly, the Guffawli Token is backed by a clear and credible team. There are still a lot of upcoming events and innovations yet to be announced. With these, Guffawli would do very well against competitors.",
        id: 4
    },
    {
        title: "Why was Guffawli built on the Binance Smart Chain?",
        content: "Guffawli is built on the Binance Smart Chain to foster speed and growth in an affordable way.",
        id: 5
    }
   
  ];

const FAQ = () => {
    return (
        <div className="FAQ">
          ÷
            
             {faqData.map((item, index) => (
                <Accordion
                    title={item.title}
                    content={item.content}
                    key={item.title + index}
                />
              ))}
             
            {/* </div> */}
        </div>
    )
}

export default FAQ