import { useEffect } from "react";
import "animate.css";
import AboutImage from "../../assets/about-image.png";
import GoalImage from "../../assets/goal-image.png";
import ValuesImage from "../../assets/values-image.png";
import "./index.css";

const About = () => {
  useEffect(() => {
    window.scroll(0, 0);
  }, []);
  return (
    <div className="home-header-wrapper">
      <div className="max-width">
        <div className="flex-container-home-header mt-100 mb-100">
          <div className="body-container col-60 animate__animated animate__fadeInLeft animate__slow">
            <h4 className="hero-title-text">About Us</h4>
            <p className="body-text">
              Guffawli is ownerless, fully decentralized, and supported by its
              community of enthusiasts. Free, open, and frank communication is
              encouraged among the community supporters so that everyone willing
              can be informed and even participate in every step of Guffawli’s
              growth! Numerous independent, free group efforts in improvement,
              community self-management, and more are encouraged.
            </p>
          </div>
          <div className="image-container col-40 animate__animated animate__fadeInRight animate__slow justify-end">
            <img alt="guffawli-web" className="about-image" src={AboutImage} />
          </div>
        </div>
        {/* OUR GOAL */}
        <div className="desktop-only mt-100 mb-100">
          <div className="flex-container-home-header">
            <div className="image-container col-40 animate__animated animate__fadeInLeft animate__slow">
              <img alt="guffawli-web" className="about-image" src={GoalImage} />
            </div>
            <div className="body-container col-60 animate__animated animate__fadeInRight animate__slow">
              <h4 className="hero-title-text">Our Goal</h4>
              <p className="body-text">
                It’s known that every merchant or investor is different. To keep
                feelings under check, develop your trading and investment
                technique based on your needs and market proficiency. In the
                light of this, from the word 'Guffaw,' we have found the
                Guffawli meme token Guffawli Token – (Guffaw meaning loud and
                hearty laugh).
              </p>

              <p className="body-text mt-20">
                Notably, mental health and emotional weakness have always been
                neglected. Now we are putting you first and enlightening
                Individuals on how a good laugh help shape psychological and
                physical experiences.
              </p>
            </div>
          </div>
        </div>
        <div className="mobile-only mt-100 mb-100">
          <div className="goals-container">
            <div className="image-container col-40 animate__animated animate__fadeInLeft animate__slow">
              <img alt="guffawli-web" className="about-image" src={GoalImage} />
            </div>
            <div className="body-container col-60 animate__animated animate__fadeInRight animate__slow">
              <h4 className="hero-title-text">Our Goal</h4>
              <p className="body-text">
                It’s known that every merchant or investor is different. To keep
                feelings under check, develop your trading and investment
                technique based on your needs and market proficiency. In the
                light of this, from the word 'Guffaw,' we have found the
                Guffawli meme token Guffawli Token – (Guffaw meaning loud and
                hearty laugh).
              </p>

              <p className="body-text mt-20">
                Notably, mental health and emotional weakness have always been
                neglected. Now we are putting you first and enlightening
                Individuals on how a good laugh help shape psychological and
                physical experiences.
              </p>
            </div>
          </div>
        </div>

        {/* OUR VALUES */}
        <div className="flex-container-home-header mt-100 mb-100">
          <div className="body-container col-60 animate__animated animate__fadeInLeft animate__slow">
            <h4 className="hero-title-text">Our Values</h4>
            <h6 className="about-subtitle">Trust</h6>
            <p className="body-text">
              In the crypto space, trust is paramount. For this reason, we have
              created a good token distribution model. Including a clear and
              credible team to foster development. The transparency of Guffawli
              would be top-notch and believe that we also consider security and
              proper management.
            </p>
            <h6 className="about-subtitle">Long term</h6>
            <p className="body-text">
              Guffawli is in it for the long term. The Guffawli community and
              team would build steadily long-term and would cause the
              development of the ecosystem which will result in real use cases,
              the greater the community the greater Guffawli and the team.
            </p>
          </div>
          <div className="image-container col-40 animate__animated animate__fadeInRight animate__slow justify-end">
            <img alt="guffawli-web" className="about-image" src={ValuesImage} />
          </div>
        </div>
      </div>
      {/* ABOUT US */}
    </div>
  );
};

export default About;
