
export const Languages = [

    {
        code: 'en',
        name: 'English',
        country_code: 'us'
    },

    {
        code: 'fr',
        name: 'français',
        country_code: 'fr'
    },

    {
        code: 'ar',
        name: 'العربية',
        // dir: 'rtl',
        country_code: 'sa',
      },
]


