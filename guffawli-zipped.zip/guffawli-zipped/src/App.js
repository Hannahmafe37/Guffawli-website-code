import Footer from "./components/footer";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./screens/home";
import Menu, { MobileMenu } from "../src/components/navbar/index";
import About from "./screens/about";
import Tokenomics from "./screens/tokenomics";
import BuyPage from "./screens/buypage";

function App() {
  return (
    <div>
      <BrowserRouter>
        <Menu />
        <MobileMenu />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/tokenomics" element={<Tokenomics />} />
          <Route path="/buy" element={<BuyPage />} />
          <Route path="/buy/options" element={<BuyPage />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
