import CoinGeckoImage from "../../assets/Coingecko.png";
import CoinMarketCapImage from "../../assets/CoinmarketCap.png";
import PancakeSwapImage from "../../assets/PancakeSwap.png";
import CoinGeckoMobileImage from "../../assets/coingeckomobile.svg";
import CoinMarketCapMobileIcon from "../../assets/coinmarketcapicon.svg";
import PancakeSwapMobileIcon from "../../assets/pancakeswapicon.svg";
import "animate.css";
import { Link } from "react-router-dom";

const EarlyAccess = () => {
  return (
    <div className="early-access-wrapper ">
      <div className="animate__animated animate__fadeInUp animate__slow">
        <div className="">
          <h4 className="hero-title-text text-center desktop-only">
            Get early access to the fastest <br />
            growing <span className="purple-text">happiest</span> meme <br />
            community
          </h4>
          <h4 className="hero-title-text text-center mobile-only">
            Get early access to the <br />
            fastest growing <span className="purple-text">happiest</span>
            <br /> meme community
          </h4>
        </div>
        <div className="early-button-wrapper">
          <Link to="/buy">
            <button className="hero-button text-center">Buy Presale</button>
          </Link>
        </div>
        <div className="early-access-image-row desktop-only">
          <img alt="guffawli-web" src={CoinGeckoImage} />
          <img alt="guffawli-web" src={CoinMarketCapImage} />
          <img alt="guffawli-web" src={PancakeSwapImage} />
        </div>
        <div className="early-access-image-row mobile-only">
          <img alt="guffawli-web" src={CoinGeckoMobileImage} />
          <img alt="guffawli-web" src={CoinMarketCapMobileIcon} />
          <img alt="guffawli-web" src={PancakeSwapMobileIcon} />
        </div>
      </div>
    </div>
  );
};

export default EarlyAccess;
