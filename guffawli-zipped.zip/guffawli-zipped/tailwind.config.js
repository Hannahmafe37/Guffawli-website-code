/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        primary: "Cherry Swash, cursive",
        circular: "Circular Std",
      },
      colors: {
        neutral: "#0E0909",
        light: "#454242",
        pink: "#FE6668",
        lightpink: "#FEC0C1",
      },
      screens: {
        mid: "1166px",
      },
    },
  },
  plugins: [],
};
