import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { ReactComponent as Lollipop } from "../../assets/lollipop.svg";
import { ReactComponent as Coin } from "../../assets/coin.svg";
import { ReactComponent as Ellipse } from "../../assets/ellipse.svg";
import Icon1 from "../../assets/hero-icon-1.svg";
import Icon2 from "../../assets/hero-icon-2.svg";
import Icon3 from "../../assets/hero-icon-3.svg";
import Icon4 from "../../assets/hero-icon-4.svg";
import HeroImage from "../../assets/hero.png";
import { buyOptions, buyMethods } from "../../utils/constants";
import ProviderModal from "../../components/modals/ProviderModal";
import ExchangeModal from "../../components/modals/ExchangeModal";

const BuyPage = () => {
  const [showProviderModal, setShowProviderModal] = useState(false);
  const [exchangeCurrency, setExchangeCurrency] = useState(null);
  const [, setConnectionMode] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();
  const isBuyOptionsPage = location.pathname === "/buy/options";
  const onSelect = (type) => {
    setConnectionMode(type);
    setShowProviderModal(false);
    navigate("/buy/options");
    window.scroll(0, 0);
  };
  return (
    <div>
      <ProviderModal
        visible={showProviderModal}
        onClose={() => setShowProviderModal(false)}
        onSelect={onSelect}
      />
      <ExchangeModal
        visible={isBuyOptionsPage && exchangeCurrency}
        onClose={() => setExchangeCurrency(null)}
        currency={exchangeCurrency}
      />
      <div className="max-width overflow-y-hidden mt-6 md:mt-[88px] blurred-coin px-5 overflow-x-hidden">
        <div className="flex flex-col space-y-5 mid:space-y-0 mid:flex-row mid:space-x-[178px]  relative">
          <div className="animate__animated animate__slideInLeft">
            <h2 className="text-neutral text-[41px] font-bold text-center md:text-left">
              Get In Early
            </h2>
            <p className="mt-4 text-light text-center mid:!text-left md:text-[25px] text-base mid:max-w-[496px] leading-[40px]">
              Guffawli is ownerless, fully decentralized, and supported by its
              community of enthusiasts. It couldn't be easier to get your hands
              on the token in our pre-sale. You can buy Guffawli directly using
              your card, or can use USDT or ETH already in your wallet. After
              the public presale ends, you'll be able to claim your purchased
              Guffawli Tokens using the claim page.
            </p>
            {isBuyOptionsPage ? (
              <div className="flex flex-col justify-center">
                {buyMethods.map((method, index) => (
                  <button
                    className="hero-button bg-pink uppercase"
                    key={index}
                    onClick={() => setExchangeCurrency(method)}
                  >
                    buy gruff with {method}
                  </button>
                ))}
              </div>
            ) : (
              <div className="flex items-center  justify-center md:items-start md:justify-start">
                <button
                  className="hero-button cursor-pointer !mt-[36px] mx-auto mid:mx-0"
                  onClick={() => setShowProviderModal(true)}
                >
                  Connect Wallet
                </button>
              </div>
            )}

            <div className="hero-icons-row animate__animated animate__rubberBand animate__slow">
              <img alt="guffawli-web" src={Icon1} className="hero-icon" />
              <img alt="guffawli-web" src={Icon2} className="hero-icon" />
              <img alt="guffawli-web" src={Icon3} className="hero-icon" />
              <img alt="guffawli-web" src={Icon4} className="hero-icon" />
            </div>
          </div>
          <div className="lg:w-[558px] mx-auto mid:mx-0 flex flex-col flex-shrink-0 lg:h-[558px] md:w-[400px] animate__animated animate__rotateInDownRight md:h-[400px] bg-pink rounded-[50%] w-full h-full shadowed">
            <div className="mt-[37px] flex flex-col items-center justify-center">
              <span className="font-neutral text-[20px] mid:text-[40px] font-bold">
                34,564,520
              </span>
              <span className="font-neutral text-[20px] mid:text-[40px] font-bold">
                Guffawli Tokens
              </span>
              <span className="font-neutral text-[20px] mid:text-[40px] font-bold">
                Remaining
              </span>
              <div className="mt-6">
                <p className="text-light text-[20px] mb-4 font-circular text-center">
                  UNTIL 1 USDT = 50.20 GUFF
                </p>
                <p className="text-light text-[20px] mb-6 font-circular text-center">
                  USDT Raised: $4,324,247.25/4,750,000
                </p>
              </div>
            </div>
            <div className="mt-6 flex items-center justify-center">
              <div className="relative bg-[#FEF1F1] h-[78px] rounded-2xl w-[220px]">
                <div
                  className="absolute left-0 top-0 rounded-2xl bg-pink h-full shadowed border-[1px] border-white"
                  style={{ width: `${(4324247.25 / 4750000) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="mt-[48px] h-[55px] w-full bg-lightpink"></div>
      <div
        className="flex items-center justify-center py-[39px] p-5 animate__animated animate__fadeIn"
        id="how-to-buy"
      >
        <h2 className="text-[41px] text-neutral font-bold">How to Buy</h2>
      </div>
      <div className="step-1 bg-lightpink relative">
        <Ellipse className="absolute right-[0]" />
        <Coin className="absolute top-" />
        <div className="max-width p-3 md:p-[26px] pb-0 md:pb-0">
          <h2 className="text-neutral text-[20px] md:text-[41px] text-center font-bold">
            Step 1
          </h2>
          <div className="flex mt-[30px] lg:mt-[48px] lg:space-x-[96px] flex-col space-y-5 lg:flex-row lg:space-y-0">
            <p className="md:ml-[190px] ml-3 max-w-[663px] leading-[40px] md:text-[25px] text-[20px] mb-[34px] relative">
              To begin, make sure you have a MetaMask wallet installed on your
              browser, or use one of the wallets supported by Wallet Connect (we
              recommend Trust Wallet). Purchasing on a desktop browser will give
              you a smoother purchasing experience. For this we recommend
              Metamask. If you are purchasing on mobile, we recommend using
              Trust Wallet and connecting through the in built browser (just
              copy https://ipsumlorem into the Trust Wallet Browser).
            </p>
            <Lollipop className="relative" />
          </div>
        </div>
      </div>
      {/* step 2 */}
      <div className="step-2">
        <div className="max-width p-3 md:p-[72px]">
          <h2 className="text-neutral text-[20px] md:text-[41px] text-center font-bold">
            Step 2
          </h2>
          <p className="mt-[20px] md:mt-[26px] text-center text-neutral">
            Once you have your preferred wallet provider ready, click “Connect
            Wallet” and select the appropriate option. For mobile wallet apps
            you will need to select “Wallet Connect”.
            <br />
            <br />
            You will then have 1 option:
          </p>
          <div className="flex justify-center mt-[20px] md:mt-[32px] md:space-x-[48px] mb-[96px] flex-col space-y-5 md:flex-row md:space-y-0">
            {buyOptions.map((option, index) => (
              <div
                className="rounded-xl bg-lightpink md:w-[356px] md:p-[22px] p-4 pt-5  md:pt-[44px] flex flex-col items-center"
                key={index}
              >
                {option.icon}
                <h3 className="mt-5 md:mt-[33px] text-[20px] md:text-[31px] font-bold">
                  {option.header}
                </h3>
                <p className="mt-4 md:mt-[22px] leading-[40px] text-[20px] md:text-[25px] font-circular font-[450] text-neutral">
                  {option.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* step 3 */}
      <div className="bg-white">
        <div className="p-3 md:p-[54px] max-width">
          <h2 className="text-neutral text-[20px] md:text-[41px] text-center font-bold">
            Step 3
          </h2>
          <div className="flex flex-col space-y-5 lg:flex-row lg:space-x-[104px] items-center justify-center">
            <img
              alt="guffawli-web"
              src={HeroImage}
              className="hero-image animate__animated animate__bounceIn animate__slow"
            />
            <p className="max-w-[611px] font-circular text-[20px] lg:text-[25px] font-[450] leading-[40px]">
              Once the presale has concluded, you will be able to claim your
              Guffawli tokens. We will release details closer to the time,
              however you will need to visit the main site https://ipsumlorem
              and click on the silver “Claim” button.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BuyPage;
