import React from "react";
import clsx from "classnames";

const BackDrop = ({ onClick, visible }) => {
  return (
    <div
      onClick={onClick}
      className={clsx(
        "opacity-0 pointer-events-none fixed h-screen w-screen top-0 left-0",
        {
          "opacity-[1] pointer-events-auto bg-black/[.8] blur-sm z-[9] transition-all":
            visible,
        }
      )}
    />
  );
};

export default BackDrop;
