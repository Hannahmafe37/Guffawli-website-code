import { Link } from "react-router-dom";
import { useEffect } from "react";
import "./index.css";
import Chart from "../../assets/chart.svg";
// import LapelBonus from "../../assets/lapel-bonus.svg";

const TwoColumnTable = () => {
  return (
    <div className="mt-50 mb-50">
      <table className="two-col-table" cellspacing="0">
        <tr>
          <td>
            <h4>Total Supply</h4>
          </td>
          <td>
            <h4>10.000.000.000 Tokens</h4>
          </td>
        </tr>
        <tr>
          <td>
            <h4>Ticker</h4>
          </td>
          <td>
            <h4>GUF</h4>
          </td>
        </tr>
        <tr>
          <td>
            <h4>Presale Date</h4>
          </td>
          <td>
            <h4>
              19th August 2022 - <br />
              10 October 2022
            </h4>
          </td>
        </tr>
        <tr>
          <td>
            <h4>Launch Date</h4>
          </td>
          <td>
            <h4>14th February 2023</h4>
          </td>
        </tr>
        <tr>
          <td>
            <h4>Price</h4>
          </td>
          <td>
            <h4>$0.005556</h4>
          </td>
        </tr>
      </table>
    </div>
  );
};

const PresaleStages = () => {
  return (
    <div className="presale-white-bg">
      <div className="presale-row max-width">
        <div className="w-one-third "></div>
        <div className="w-one-third flex-center">
          <h4 className="hero-title-text text-center">Presale Stages</h4>
        </div>
        {/* <div className="w-one-third flex-end">
          <img alt="guffawli-web" src={LapelBonus} />
        </div> */}
      </div>

      <div className="mobile-only mt-20">
        <div>
          <h4 className="hero-title-text text-center">Presale Stages</h4>
        </div>
        {/* <div className="presale-bonus-bg">
          <p>Get</p>
          <h4>20% Bonus</h4>
          <p>on your first purchase!</p>
        </div> */}
      </div>

      <div className="presale-table-container max-width">
        <table className="presale-table" cellspacing="0" cellpadding="0">
          <tr className="presale-table-head">
            <th>
              <h4 className="data-card-title text-center">Stages</h4>
            </th>
            <th>
              <h4 className="data-card-title">Date</h4>
            </th>
            <th>
              <h4 className="data-card-title">Number of Tokens</h4>
            </th>
            <th>
              <h4 className="data-card-title">Allocations</h4>
            </th>
            {/* <th>
              <h4 className="data-card-title">Bonus</h4>
            </th> */}
          </tr>
          <tr className="presale-table-body">
            <td className="data-card-body">
              <h4>Stage 1</h4>
            </td>
            <td>
              <h4 className="">5th August to 10th October</h4>
            </td>
            <td>
              <h4>1.800.000.000 Tokens</h4>
            </td>
            <td>
              <h4>18%</h4>
            </td>
            {/* <td>
              <h4>20%</h4>
            </td> */}
          </tr>
          <tr className="presale-table-body">
            <td className="data-card-body">
              <h4>Stage 2</h4>
            </td>
            <td>
              <h4 className="">10th October to 28th November</h4>
            </td>
            <td>
              <h4>750.000.000 Tokens</h4>
            </td>
            <td>
              <h4>7.5%</h4>
            </td>
            {/* <td>
              <h4>20%</h4>
            </td> */}
          </tr>
          <tr className="presale-table-body">
            <td className="data-card-body">
              <h4>Stage 3</h4>
            </td>
            <td>
              <h4 className="">28th November to 13th January</h4>
            </td>
            <td>
              <h4>450.000.000 Tokens</h4>
            </td>
            <td>
              <h4>4.5%</h4>
            </td>
            {/* <td>
              <h4>20%</h4>
            </td> */}
          </tr>
        </table>
      </div>
      <div className="early-button-wrapper max-width">
        <Link to="/buy">
          <button className="hero-button text-center">Buy Presale</button>
        </Link>
      </div>
    </div>
  );
};

const DataSection = () => {
  return (
    <div className=" chart-row max-width">
      <div className="flex-container">
        <div className="col-half chart-wrapper">
          <img alt="guffawli-web" src={Chart} className="chart-icon" />
        </div>
        <div className="col-half">
          <div>
            <div className="flex-row gap-20 mt-20">
              <div className="data-card">
                <div>
                  <p className="data-card-title"> 40% Liquidity</p>
                  <h4 className="data-card-body">4,000,000,000</h4>
                </div>
              </div>
              <div className="data-card">
                <div>
                  <p className="data-card-title"> 30% Presale</p>
                  <h4 className="data-card-body">3,000,000,000</h4>
                </div>
              </div>
            </div>
            <div className="flex-row gap-20 mt-20">
              <div className="data-card">
                <div>
                  <p className="data-card-title"> 17% Rewards</p>
                  <h4 className="data-card-body">1,700,000,000</h4>
                </div>
              </div>
              <div className="data-card">
                <div>
                  <p className="data-card-title"> 7% Promotions</p>
                  <h4 className="data-card-body">700,000,000</h4>
                </div>
              </div>
            </div>
            <div className=" gap-20 mt-20">
              <div className="data-card">
                <div>
                  <p className="data-card-title"> 6% Team</p>
                  <h4 className="data-card-body">600,000,000</h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const HeadSection = () => {
  return (
    <div className="home-header-wrapper">
      <div className="max-width">
        <div className="flex-container">
          <div className="col-half">
            <h4 className="hero-title-text text-left">Tokenomics</h4>
            <p className="tokenomics-text">
              Guffawli meme coins will be used as a lot just as other coins in
              the blockchain network to purchase, stake, and trade, allowing
              them to become another integral part of the system.
            </p>
            <h4 className="supply-text">Total Supply - 10,000,000,000</h4>
          </div>
          <div className="col-half">
            <div className="two-col-table-container">
              <TwoColumnTable />
            </div>

            {/* <div className='flex-container'>

                    </div> */}
          </div>
        </div>
      </div>
    </div>
  );
};

const Tokenomics = () => {
  useEffect(() => {
    window.scroll(0, 0);
  }, []);
  return (
    <div>
      <HeadSection />
      <DataSection />
      <PresaleStages />
    </div>
  );
};

export default Tokenomics;
